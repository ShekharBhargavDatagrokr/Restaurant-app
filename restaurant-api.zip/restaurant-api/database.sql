CREATE DATABASE restaurant_database;

--\c to move into database

CREATE TABLE restaurant_table(
    reservation_id SERIAL PRIMARY KEY,
    user_name VARCHAR(255),
    mobile_number INTEGER,
    no_of_people INTEGER,
    time_of_reservation TIMESTAMP NOT null DEFAULT CURRENT_TIMESTAMP
);